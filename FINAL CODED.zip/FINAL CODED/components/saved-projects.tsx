"use client"

import { FileCode, FolderOpen, Plus } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { getSavedProjects } from "@/app/actions/dashboard-actions"
import Link from "next/link"

export function SavedProjects({ showEmpty = false, showAll = false }) {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const projectsData = await getSavedProjects()
        setProjects(projectsData)
      } catch (error) {
        console.error("Error fetching saved projects:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return <div className="flex items-center justify-center h-[200px]">Loading projects...</div>
  }

  if (projects.length === 0 && showEmpty) {
    return (
      <div className="text-center py-8">
        <FileCode className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">No Projects Yet</h3>
        <p className="text-muted-foreground mb-4">Create your first coding project in the IDE</p>
        <Button asChild>
          <Link href="/ide">
            <Plus className="h-4 w-4 mr-2" />
            New Project
          </Link>
        </Button>
      </div>
    )
  }

  const displayProjects = showAll ? projects : projects.slice(0, 4)

  return (
    <div className="space-y-4">
      {displayProjects.map((project) => (
        <div key={project.id} className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
              <FileCode className="h-4 w-4 text-primary" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium">{project.name}</p>
                <Badge variant={project.status === "Completed" ? "default" : "outline"}>{project.status}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{project.language}</p>
              <p className="text-xs text-muted-foreground">Last edited: {project.lastEdited}</p>
            </div>
          </div>
          <Link href={`/ide?project=${project.id}`} className="rounded-md p-1 hover:bg-accent">
            <FolderOpen className="h-4 w-4" />
          </Link>
        </div>
      ))}

      {showAll && projects.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button asChild variant="outline">
            <Link href="/ide">
              <Plus className="h-4 w-4 mr-2" />
              New Project
            </Link>
          </Button>
        </div>
      )}

      {!showAll && projects.length > 4 && (
        <div className="flex justify-end">
          <Button asChild variant="link" size="sm">
            <Link href="/ide">View all projects</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
