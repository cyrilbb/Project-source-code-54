"use client"

import { Bug, Clock, Puzzle, Rocket, Gamepad } from "lucide-react"
import { useEffect, useState } from "react"
import { getRecentGames } from "@/app/actions/dashboard-actions"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const iconMap = {
  Bug: Bug,
  Clock: Clock,
  Puzzle: Puzzle,
  Rocket: Rocket,
  Gamepad: Gamepad,
}

export function RecentGames({ showAll = false }) {
  const [games, setGames] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const gamesData = await getRecentGames()
        setGames(gamesData)
      } catch (error) {
        console.error("Error fetching recent games:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return <div className="flex items-center justify-center h-[200px]">Loading recent games...</div>
  }

  if (games.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground mb-4">You haven't played any games yet.</p>
        <Button asChild>
          <Link href="/games">Play Now</Link>
        </Button>
      </div>
    )
  }

  const displayGames = showAll ? games : games.slice(0, 4)

  return (
    <div className="space-y-4">
      {displayGames.map((game) => {
        const IconComponent = iconMap[game.icon] || Gamepad

        return (
          <div key={game.id} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
                <IconComponent className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">{game.name}</p>
                <p className="text-xs text-muted-foreground">{game.date}</p>
              </div>
            </div>
            <div className="text-sm font-medium">{game.score} pts</div>
          </div>
        )
      })}

      {!showAll && games.length > 4 && (
        <div className="flex justify-end">
          <Button asChild variant="link" size="sm">
            <Link href="/games">View all games</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
