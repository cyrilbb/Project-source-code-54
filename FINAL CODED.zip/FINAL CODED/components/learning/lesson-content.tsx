"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Editor } from "@monaco-editor/react"
import { useTheme } from "next-themes"
import { ArrowLeft, ArrowRight, Check, Play, Loader2 } from "lucide-react"
import { markLessonAsCompleted, updateLessonProgress } from "@/app/actions/learning-actions"
import { executeCode } from "@/lib/code-execution"

export function LessonContent({ lesson, moduleId, progress }) {
  const router = useRouter()
  const { theme } = useTheme()
  const [currentStep, setCurrentStep] = useState(progress?.lastPosition || 0)
  const [code, setCode] = useState("")
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [isCompleting, setIsCompleting] = useState(false)
  const [editorLanguage, setEditorLanguage] = useState("javascript")

  const content = lesson.content || []
  const totalSteps = content.length
  const currentContent = content[currentStep] || {}
  const isLastStep = currentStep === totalSteps - 1
  const isFirstStep = currentStep === 0

  // Initialize code editor with content
  useEffect(() => {
    if (currentContent.contentType === "code" || currentContent.contentType === "exercise") {
      setCode(currentContent.codeSnippet || "")
      setEditorLanguage(currentContent.language || "javascript")
    }
  }, [currentContent])

  // Update progress when changing steps
  useEffect(() => {
    if (currentStep !== (progress?.lastPosition || 0)) {
      updateLessonProgress(lesson.id, currentStep)
    }
  }, [currentStep, lesson.id, progress?.lastPosition])

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = async () => {
    setIsCompleting(true)
    try {
      await markLessonAsCompleted(lesson.id)
      router.refresh()
    } catch (error) {
      console.error("Error completing lesson:", error)
    } finally {
      setIsCompleting(false)
    }
  }

  const runCode = async () => {
    setIsRunning(true)
    setOutput("Running code...\n")

    try {
      const result = await executeCode(code, editorLanguage)

      let outputText = ""
      if (result.stdout) {
        outputText += result.stdout
      }
      if (result.stderr) {
        outputText += `Error:\n${result.stderr}\n`
      }

      outputText += `\nExecution time: ${result.executionTime.toFixed(2)}ms | Memory used: ${result.memory.toFixed(2)}KB | Exit code: ${result.exitCode}`
      setOutput(outputText)
    } catch (error) {
      setOutput(`Error executing code: ${error.message}`)
    } finally {
      setIsRunning(false)
    }
  }

  const renderContent = () => {
    switch (currentContent.contentType) {
      case "text":
        return (
          <div className="prose dark:prose-invert max-w-none">
            <h2>{currentContent.title}</h2>
            <div dangerouslySetInnerHTML={{ __html: currentContent.body }} />
          </div>
        )

      case "code":
        return (
          <div className="space-y-4">
            <div className="prose dark:prose-invert max-w-none">
              <h2>{currentContent.title}</h2>
              <div dangerouslySetInnerHTML={{ __html: currentContent.body }} />
            </div>

            <Card>
              <CardContent className="p-0">
                <Tabs defaultValue="code" className="w-full">
                  <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
                    <TabsTrigger
                      value="code"
                      className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent"
                    >
                      Code
                    </TabsTrigger>
                    <TabsTrigger
                      value="output"
                      className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent"
                    >
                      Output
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="code" className="mt-0">
                    <div className="h-[300px] border-0">
                      <Editor
                        height="300px"
                        language={editorLanguage}
                        value={code}
                        theme={theme === "dark" ? "vs-dark" : "light"}
                        onChange={(value) => setCode(value)}
                        options={{
                          minimap: { enabled: false },
                          scrollBeyondLastLine: false,
                          fontSize: 14,
                          readOnly: currentContent.contentType !== "exercise",
                        }}
                      />
                    </div>
                    {currentContent.contentType === "exercise" && (
                      <div className="flex justify-end p-2 border-t">
                        <Button onClick={runCode} disabled={isRunning}>
                          {isRunning ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                              Running
                            </>
                          ) : (
                            <>
                              <Play className="h-4 w-4 mr-1" />
                              Run Code
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </TabsContent>
                  <TabsContent value="output" className="mt-0">
                    <div className="h-[300px] p-4 font-mono text-sm overflow-auto whitespace-pre-wrap">
                      {output || "Run your code to see output here."}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )

      case "exercise":
        return (
          <div className="space-y-4">
            <div className="prose dark:prose-invert max-w-none">
              <h2>{currentContent.title}</h2>
              <div dangerouslySetInnerHTML={{ __html: currentContent.body }} />
            </div>

            <Card>
              <CardContent className="p-0">
                <Tabs defaultValue="code" className="w-full">
                  <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
                    <TabsTrigger
                      value="code"
                      className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent"
                    >
                      Code
                    </TabsTrigger>
                    <TabsTrigger
                      value="output"
                      className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent"
                    >
                      Output
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="code" className="mt-0">
                    <div className="h-[300px] border-0">
                      <Editor
                        height="300px"
                        language={editorLanguage}
                        value={code}
                        theme={theme === "dark" ? "vs-dark" : "light"}
                        onChange={(value) => setCode(value)}
                        options={{
                          minimap: { enabled: false },
                          scrollBeyondLastLine: false,
                          fontSize: 14,
                        }}
                      />
                    </div>
                    <div className="flex justify-end p-2 border-t">
                      <Button onClick={runCode} disabled={isRunning}>
                        {isRunning ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                            Running
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-1" />
                            Run Code
                          </>
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                  <TabsContent value="output" className="mt-0">
                    <div className="h-[300px] p-4 font-mono text-sm overflow-auto whitespace-pre-wrap">
                      {output || "Run your code to see output here."}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )

      case "quiz":
        return (
          <div className="prose dark:prose-invert max-w-none">
            <h2>{currentContent.title}</h2>
            <div dangerouslySetInnerHTML={{ __html: currentContent.body }} />
          </div>
        )

      default:
        return (
          <div className="prose dark:prose-invert max-w-none">
            <p>Content not available.</p>
          </div>
        )
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-card rounded-lg border p-6">{renderContent()}</div>

      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={handlePrevious} disabled={isFirstStep}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Previous
        </Button>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {currentStep + 1} of {totalSteps}
          </span>
        </div>

        {isLastStep ? (
          <div className="flex gap-2">
            {!progress?.isCompleted && (
              <Button onClick={handleComplete} disabled={isCompleting}>
                {isCompleting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Completing...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 mr-2" />
                    Complete Lesson
                  </>
                )}
              </Button>
            )}
            <Button asChild variant={progress?.isCompleted ? "default" : "outline"}>
              <Link href={`/learning/${moduleId}`}>Back to Module</Link>
            </Button>
          </div>
        ) : (
          <Button onClick={handleNext}>
            Next
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        )}
      </div>
    </div>
  )
}
