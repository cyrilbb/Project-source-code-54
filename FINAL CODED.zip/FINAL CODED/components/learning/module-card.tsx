import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Check, Clock } from "lucide-react"

export function ModuleCard({ module, progress, completed }) {
  const getIcon = () => {
    if (completed) {
      return <Check className="h-5 w-5 text-green-500" />
    } else if (progress > 0) {
      return <Clock className="h-5 w-5 text-primary" />
    } else {
      return <BookOpen className="h-5 w-5 text-primary" />
    }
  }

  const getStatusText = () => {
    if (completed) {
      return "Completed"
    } else if (progress > 0) {
      return "In Progress"
    } else {
      return "Not Started"
    }
  }

  return (
    <Card
      className={`
      overflow-hidden
      ${completed ? "bg-green-500/5 border-green-500/20" : ""}
      ${progress > 0 && !completed ? "bg-primary/5 border-primary/20" : ""}
    `}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>{module.title}</CardTitle>
          <Badge variant="outline" className="bg-primary/5">
            {module.language}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3 min-h-[4.5rem] text-sm text-muted-foreground">{module.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className={`
              flex h-8 w-8 items-center justify-center rounded-full 
              ${completed ? "bg-green-500/10" : "bg-primary/10"}
            `}
            >
              {getIcon()}
            </div>
            <span className="text-sm">{getStatusText()}</span>
          </div>
          <Badge variant="outline">{module.difficulty}</Badge>
        </div>
        {progress > 0 && !completed && (
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs mb-1">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <div className="h-1.5 w-full rounded-full bg-primary/20">
              <div className="h-1.5 rounded-full bg-primary" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/learning/${module.id}`}>
            {completed ? "Review Module" : progress > 0 ? "Continue" : "Start Learning"}
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
