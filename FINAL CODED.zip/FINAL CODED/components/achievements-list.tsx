"use client"

import { Award, Flame, Star, Zap } from "lucide-react"
import { useEffect, useState } from "react"
import { getAchievements } from "@/app/actions/dashboard-actions"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const iconMap = {
  Star: Star,
  Zap: Zap,
  Flame: Flame,
  Award: Award,
}

export function AchievementsList({ showAll = false }) {
  const [achievements, setAchievements] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        const achievementsData = await getAchievements()
        setAchievements(achievementsData)
      } catch (error) {
        console.error("Error fetching achievements:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return <div className="flex items-center justify-center h-[200px]">Loading achievements...</div>
  }

  if (achievements.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-muted-foreground mb-4">Complete activities to earn achievements and badges.</p>
        <Button asChild>
          <Link href="/games">Play Games</Link>
        </Button>
      </div>
    )
  }

  const displayAchievements = showAll ? achievements : achievements.slice(0, 4)

  return (
    <div className="space-y-4">
      {displayAchievements.map((achievement) => {
        const IconComponent = iconMap[achievement.icon] || Award

        return (
          <div key={achievement.id} className="flex items-start gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10">
              <IconComponent className="h-5 w-5 text-primary" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium leading-none">{achievement.name}</p>
              <p className="text-xs text-muted-foreground">{achievement.description}</p>
              <p className="text-xs text-muted-foreground">{achievement.date}</p>
            </div>
          </div>
        )
      })}

      {!showAll && achievements.length > 4 && (
        <div className="flex justify-end">
          <Button asChild variant="link" size="sm">
            <Link href="/profile">View all achievements</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
