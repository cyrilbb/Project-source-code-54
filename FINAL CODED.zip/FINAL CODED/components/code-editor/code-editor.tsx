"use client"

import { useState, useRef, useEffect } from "react"
import { Editor } from "@monaco-editor/react"
import { useTheme } from "next-themes"
import { Loader2, Play, Save, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { executeCode } from "@/lib/code-execution"
import { createProject, updateProject } from "@/app/actions/project-actions"
import { toast } from "@/components/ui/use-toast"

// Language options
const LANGUAGES = [
  {
    id: "python",
    name: "Python",
    extension: ".py",
    defaultCode: "# Write your Python code here\n\nprint('Hello, World!')",
  },
  {
    id: "javascript",
    name: "JavaScript",
    extension: ".js",
    defaultCode: "// Write your JavaScript code here\n\nconsole.log('Hello, World!');",
  },
  {
    id: "typescript",
    name: "TypeScript",
    extension: ".ts",
    defaultCode:
      "// Write your TypeScript code here\n\nfunction greet(name: string): string {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(greet('World'));",
  },
  {
    id: "cpp",
    name: "C++",
    extension: ".cpp",
    defaultCode:
      '// Write your C++ code here\n\n#include <iostream>\n\nint main() {\n  std::cout << "Hello, World!" << std::endl;\n  return 0;\n}',
  },
]

export function CodeEditor({ initialProjects = [] }) {
  const { theme } = useTheme()
  const [language, setLanguage] = useState("python")
  const [code, setCode] = useState(LANGUAGES[0].defaultCode)
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [currentProject, setCurrentProject] = useState(null)
  const [showNewProjectDialog, setShowNewProjectDialog] = useState(false)
  const [newProjectData, setNewProjectData] = useState({
    name: "",
    description: "",
    language: "python",
  })
  const editorRef = useRef(null)

  // Handle editor mount
  function handleEditorDidMount(editor) {
    editorRef.current = editor
    setIsLoading(false)
  }

  // Run code
  async function runCode() {
    if (!editorRef.current) return

    const codeToRun = editorRef.current.getValue()
    setIsRunning(true)
    setOutput("Running code...\n")

    try {
      const result = await executeCode(codeToRun, language, input)

      let outputText = ""
      if (result.stdout) {
        outputText += result.stdout
      }
      if (result.stderr) {
        outputText += `Error:\n${result.stderr}\n`
      }

      outputText += `\nExecution time: ${result.executionTime.toFixed(2)}ms | Memory used: ${result.memory.toFixed(2)}KB | Exit code: ${result.exitCode}`
      setOutput(outputText)
    } catch (error) {
      setOutput(`Error executing code: ${error.message}`)
    } finally {
      setIsRunning(false)
    }
  }

  // Save current code as a new project
  async function handleCreateProject(e) {
    e.preventDefault()

    if (!editorRef.current) return

    try {
      const codeContent = editorRef.current.getValue()
      const project = await createProject({
        name: newProjectData.name,
        description: newProjectData.description,
        language,
        codeContent,
      })

      setCurrentProject(project)
      setShowNewProjectDialog(false)
      setNewProjectData({ name: "", description: "", language: "python" })

      toast({
        title: "Project created",
        description: `Project "${project.name}" has been created successfully.`,
      })
    } catch (error) {
      toast({
        title: "Error creating project",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  // Save changes to current project
  async function saveCurrentProject() {
    if (!currentProject || !editorRef.current) return

    try {
      const codeContent = editorRef.current.getValue()
      const updatedProject = await updateProject(currentProject.id, {
        codeContent,
        language,
      })

      setCurrentProject(updatedProject)

      toast({
        title: "Project saved",
        description: `Project "${updatedProject.name}" has been saved successfully.`,
      })
    } catch (error) {
      toast({
        title: "Error saving project",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  // Change language
  function handleLanguageChange(value) {
    setLanguage(value)
    if (!currentProject) {
      const selectedLanguage = LANGUAGES.find((lang) => lang.id === value)
      setCode(selectedLanguage.defaultCode)
    }
  }

  // Create a new file (reset editor)
  function createNewFile() {
    setCurrentProject(null)
    const selectedLanguage = LANGUAGES.find((lang) => lang.id === language)
    setCode(selectedLanguage.defaultCode)
  }

  // Update code when language or current project changes
  useEffect(() => {
    if (currentProject) {
      setCode(currentProject.codeContent)
    } else {
      const selectedLanguage = LANGUAGES.find((lang) => lang.id === language)
      setCode(selectedLanguage.defaultCode)
    }
  }, [language, currentProject])

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex items-center justify-between border-b bg-card p-2">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={createNewFile}>
            <Plus className="h-4 w-4 mr-1" />
            New File
          </Button>
          <Select value={language} onValueChange={handleLanguageChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.id} value={lang.id}>
                  {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showNewProjectDialog} onOpenChange={setShowNewProjectDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Save className="h-4 w-4 mr-1" />
                Save As
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleCreateProject}>
                <DialogHeader>
                  <DialogTitle>Save Project</DialogTitle>
                  <DialogDescription>Create a new project to save your code.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Project Name</Label>
                    <Input
                      id="name"
                      value={newProjectData.name}
                      onChange={(e) => setNewProjectData({ ...newProjectData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description (optional)</Label>
                    <Textarea
                      id="description"
                      value={newProjectData.description}
                      onChange={(e) => setNewProjectData({ ...newProjectData, description: e.target.value })}
                      rows={3}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">Save Project</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

          {currentProject && (
            <Button variant="outline" size="sm" onClick={saveCurrentProject}>
              <Save className="h-4 w-4 mr-1" />
              Save
            </Button>
          )}

          <Button onClick={runCode} disabled={isRunning || isLoading} size="sm">
            {isRunning ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                Running
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-1" />
                Run
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-1 flex-col md:flex-row overflow-hidden">
        {/* Code editor */}
        <div className="h-1/2 md:h-full md:w-3/5 overflow-hidden">
          {isLoading ? (
            <div className="flex h-full items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <Editor
              height="100%"
              language={language}
              value={code}
              theme={theme === "dark" ? "vs-dark" : "light"}
              onMount={handleEditorDidMount}
              onChange={(value) => setCode(value)}
              options={{
                minimap: { enabled: false },
                scrollBeyondLastLine: false,
                fontSize: 14,
                automaticLayout: true,
              }}
            />
          )}
        </div>

        {/* Input/Output panel */}
        <div className="h-1/2 md:h-full md:w-2/5 overflow-hidden bg-card border-t md:border-t-0 md:border-l">
          <Tabs defaultValue="output" className="h-full flex flex-col">
            <div className="border-b px-4">
              <TabsList className="mt-2">
                <TabsTrigger value="output">Output</TabsTrigger>
                <TabsTrigger value="input">Input</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="output" className="flex-1 p-0 m-0 overflow-auto">
              <pre className="p-4 font-mono text-sm whitespace-pre-wrap">{output}</pre>
            </TabsContent>
            <TabsContent value="input" className="flex-1 p-4 m-0">
              <div className="space-y-2">
                <Label htmlFor="input">Standard Input</Label>
                <Textarea
                  id="input"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter input for your program here..."
                  className="font-mono resize-none h-[calc(100%-2rem)]"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
