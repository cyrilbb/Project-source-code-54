"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Editor } from "@monaco-editor/react"
import { useTheme } from "next-themes"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, Check, X, ArrowLeft, Trophy, Brain, Code, Bug, Zap } from "lucide-react"
import { submitGameScore } from "@/app/actions/game-actions"
import { toast } from "@/components/ui/use-toast"

const gameIcons = {
  "Debug Challenge": <Bug className="h-5 w-5" />,
  "Syntax Quiz": <Code className="h-5 w-5" />,
  "Algorithm Challenge": <Brain className="h-5 w-5" />,
  "Code Completion": <Zap className="h-5 w-5" />,
}

export function GameInterface({ game, challenges, leaderboard }) {
  const router = useRouter()
  const { theme } = useTheme()
  const [currentChallengeIndex, setCurrentChallengeIndex] = useState(0)
  const [userCode, setUserCode] = useState("")
  const [userAnswer, setUserAnswer] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [result, setResult] = useState(null)
  const [gameComplete, setGameComplete] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(game.name.includes("Quiz") ? 30 : 300) // 30 seconds for quiz, 5 minutes for coding
  const timerRef = useRef(null)
  const editorRef = useRef(null)

  const currentChallenge = challenges[currentChallengeIndex]

  // Initialize the game
  useEffect(() => {
    if (currentChallenge && currentChallenge.code) {
      setUserCode(currentChallenge.code)
    }

    // Start the timer
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current)
          if (!gameComplete) {
            handleTimeUp()
          }
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [currentChallenge, gameComplete])

  // Handle editor mount
  function handleEditorDidMount(editor, monaco) {
    editorRef.current = editor
  }

  // Handle time up
  function handleTimeUp() {
    if (game.name.includes("Quiz")) {
      // For quiz games, move to next question or end game
      if (currentChallengeIndex < challenges.length - 1) {
        moveToNextChallenge()
      } else {
        endGame()
      }
    } else {
      // For coding games, end the game
      endGame()
    }
  }

  // Submit the current challenge
  async function submitChallenge() {
    setIsSubmitting(true)

    try {
      let isCorrect = false
      let points = 0

      // Different validation based on game type
      if (game.name === "Debug Challenge" || game.name === "Code Completion") {
        // For debugging and code completion, compare with solution
        const code = editorRef.current.getValue()
        // Simplified check - in a real app, you'd run tests or compare ASTs
        isCorrect = code.replace(/\s+/g, "") === currentChallenge.solution.replace(/\s+/g, "")
        points = isCorrect ? currentChallenge.points : 0
      } else if (game.name === "Syntax Quiz") {
        // For quiz, check if answer is correct
        isCorrect = userAnswer === currentChallenge.correctAnswer
        points = isCorrect ? currentChallenge.points : 0
      } else if (game.name === "Algorithm Challenge") {
        // For algorithm challenges, run test cases
        const code = editorRef.current.getValue()
        // In a real app, you'd execute the code against test cases
        // This is a simplified check
        isCorrect = true // Assume correct for demo
        points = isCorrect ? currentChallenge.points : 0
      }

      // Update score
      if (isCorrect) {
        setScore((prev) => prev + points)
      }

      // Set result
      setResult({
        isCorrect,
        points,
        message: isCorrect
          ? `Correct! You earned ${points} points.`
          : "Not quite right. Try again or move to the next challenge.",
        timeBonus: Math.floor(timeLeft / 10), // Bonus points for quick completion
      })

      // If correct, add time bonus to score
      if (isCorrect) {
        setScore((prev) => prev + Math.floor(timeLeft / 10))
      }
    } catch (error) {
      console.error("Error submitting challenge:", error)
      setResult({
        isCorrect: false,
        points: 0,
        message: "An error occurred while checking your solution.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Move to the next challenge
  function moveToNextChallenge() {
    if (currentChallengeIndex < challenges.length - 1) {
      setCurrentChallengeIndex((prev) => prev + 1)
      setResult(null)
      setUserAnswer("")
      setTimeLeft(game.name.includes("Quiz") ? 30 : 300)
    } else {
      endGame()
    }
  }

  // End the game and submit the score
  async function endGame() {
    setGameComplete(true)
    clearInterval(timerRef.current)

    try {
      // Submit the final score to the database
      await submitGameScore(game.id, score)

      toast({
        title: "Game Complete!",
        description: `You scored ${score} points. Great job!`,
      })
    } catch (error) {
      console.error("Error submitting score:", error)
      toast({
        title: "Error Saving Score",
        description: "There was a problem saving your score.",
        variant: "destructive",
      })
    }
  }

  // Format time display
  function formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Game header */}
      <div className="flex items-center justify-between border-b bg-card p-4">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => router.push("/games")}>
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Games
          </Button>
          <div className="flex items-center gap-2 ml-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
              {gameIcons[game.name] || <Code className="h-4 w-4 text-primary" />}
            </div>
            <h1 className="text-xl font-bold">{game.name}</h1>
            <Badge variant="outline">{game.difficulty}</Badge>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm">
            Score: <span className="font-bold">{score}</span>
          </div>
          <div className="text-sm">
            Time: <span className={`font-bold ${timeLeft < 10 ? "text-destructive" : ""}`}>{formatTime(timeLeft)}</span>
          </div>
          <div className="text-sm">
            Challenge:{" "}
            <span className="font-bold">
              {currentChallengeIndex + 1}/{challenges.length}
            </span>
          </div>
        </div>
      </div>

      {/* Game content */}
      <div className="flex-1 overflow-auto p-4">
        {gameComplete ? (
          <GameComplete score={score} game={game} leaderboard={leaderboard} />
        ) : (
          <div className="mx-auto max-w-6xl">
            <Tabs defaultValue="challenge" className="h-full">
              <TabsList>
                <TabsTrigger value="challenge">Challenge</TabsTrigger>
                <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
              </TabsList>

              <TabsContent value="challenge" className="h-full">
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle>
                      {game.name === "Syntax Quiz"
                        ? `Question ${currentChallengeIndex + 1}: ${currentChallenge.question}`
                        : currentChallenge.title}
                    </CardTitle>
                    <CardDescription>{game.name === "Syntax Quiz" ? "" : currentChallenge.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {game.name === "Syntax Quiz" ? (
                      <RadioGroup value={userAnswer} onValueChange={setUserAnswer} className="space-y-3">
                        {currentChallenge.options.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <RadioGroupItem value={option} id={`option-${index}`} />
                            <Label htmlFor={`option-${index}`} className="font-normal">
                              {option}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    ) : (
                      <div className="h-[400px] border rounded-md overflow-hidden">
                        <Editor
                          height="100%"
                          language={currentChallenge.language}
                          value={userCode}
                          theme={theme === "dark" ? "vs-dark" : "light"}
                          onChange={(value) => setUserCode(value)}
                          onMount={handleEditorDidMount}
                          options={{
                            minimap: { enabled: false },
                            scrollBeyondLastLine: false,
                            fontSize: 14,
                          }}
                        />
                      </div>
                    )}

                    {result && (
                      <Alert className={`mt-4 ${result.isCorrect ? "border-green-500" : "border-red-500"}`}>
                        <div className="flex items-center gap-2">
                          {result.isCorrect ? (
                            <Check className="h-4 w-4 text-green-500" />
                          ) : (
                            <X className="h-4 w-4 text-red-500" />
                          )}
                          <AlertTitle>{result.isCorrect ? "Correct!" : "Incorrect"}</AlertTitle>
                        </div>
                        <AlertDescription>
                          {result.message}
                          {result.isCorrect && result.timeBonus > 0 && (
                            <p className="mt-1">Time bonus: +{result.timeBonus} points</p>
                          )}
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={moveToNextChallenge}>
                      {currentChallengeIndex < challenges.length - 1 ? "Skip" : "Finish Game"}
                    </Button>
                    <Button onClick={submitChallenge} disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Checking...
                        </>
                      ) : (
                        "Submit Answer"
                      )}
                    </Button>
                  </CardFooter>
                </Card>

                {currentChallenge.hint && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Hint</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{currentChallenge.hint}</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="leaderboard">
                <Card>
                  <CardHeader>
                    <CardTitle>Leaderboard</CardTitle>
                    <CardDescription>Top players for {game.name}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {leaderboard.length > 0 ? (
                      <div className="space-y-4">
                        {leaderboard.map((entry, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 font-bold">
                                {index + 1}
                              </div>
                              <Avatar className="h-8 w-8">
                                <AvatarImage
                                  src={entry.user.avatarUrl || "/placeholder.svg"}
                                  alt={entry.user.displayName || entry.user.username}
                                />
                                <AvatarFallback>{(entry.user.displayName || entry.user.username)[0]}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{entry.user.displayName || entry.user.username}</p>
                              </div>
                            </div>
                            <div className="font-bold">{entry.score.toLocaleString()} pts</div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground">No scores recorded yet. Be the first!</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  )
}

function GameComplete({ score, game, leaderboard }) {
  const router = useRouter()
  const isHighScore = leaderboard.length === 0 || score > leaderboard[leaderboard.length - 1]?.score

  return (
    <div className="flex flex-col items-center justify-center h-full max-w-md mx-auto text-center">
      <div className="mb-6">
        <Trophy className="h-16 w-16 text-yellow-500" />
      </div>
      <h1 className="text-3xl font-bold mb-2">Game Complete!</h1>
      <p className="text-muted-foreground mb-6">You've completed {game.name}</p>

      <div className="text-5xl font-bold mb-8">{score} points</div>

      {isHighScore && (
        <Alert className="mb-6 border-yellow-500">
          <Trophy className="h-4 w-4 text-yellow-500" />
          <AlertTitle>New High Score!</AlertTitle>
          <AlertDescription>Congratulations! You've achieved a new high score for this game.</AlertDescription>
        </Alert>
      )}

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => router.push("/games")}>
          Back to Games
        </Button>
        <Button onClick={() => router.refresh()}>Play Again</Button>
      </div>
    </div>
  )
}
