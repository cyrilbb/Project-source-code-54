import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export function GameCard({ game, icon }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">{icon}</div>
          <CardTitle>{game.name}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="line-clamp-3 min-h-[4.5rem]">{game.description}</CardDescription>
        <div className="mt-2 flex items-center gap-2">
          <Badge variant="outline">{game.difficulty}</Badge>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/games/${game.id}`}>Play Now</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
