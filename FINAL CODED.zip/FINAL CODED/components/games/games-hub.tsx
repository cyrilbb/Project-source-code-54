"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { formatTimeAgo } from "@/lib/utils"
import { Bug, Trophy, Brain, Code, Zap, Award, Star } from "lucide-react"
import { GameCard } from "@/components/games/game-card"

const gameIcons = {
  "Debug Challenge": <Bug className="h-5 w-5" />,
  "Syntax Quiz": <Code className="h-5 w-5" />,
  "Algorithm Challenge": <Brain className="h-5 w-5" />,
  "Code Completion": <Zap className="h-5 w-5" />,
}

export function GamesHub({ games, stats }) {
  return (
    <Tabs defaultValue="games" className="space-y-4">
      <TabsList>
        <TabsTrigger value="games">Games</TabsTrigger>
        <TabsTrigger value="stats">My Stats</TabsTrigger>
        <TabsTrigger value="achievements">Achievements</TabsTrigger>
      </TabsList>

      <TabsContent value="games" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {games.map((game) => (
            <GameCard key={game.id} game={game} icon={gameIcons[game.name] || <Code className="h-5 w-5" />} />
          ))}
        </div>
      </TabsContent>

      <TabsContent value="stats" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Games Played</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.gamesPlayed || 0}</div>
              <p className="mt-2 text-xs text-muted-foreground">Across all game types</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalScore?.toLocaleString() || 0}</div>
              <p className="mt-2 text-xs text-muted-foreground">Points earned from all games</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">XP Earned</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.floor((stats?.totalScore || 0) / 10)}</div>
              <p className="mt-2 text-xs text-muted-foreground">1 XP for every 10 points</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {/* This would come from the achievements count */}
                {stats?.achievements?.length || 0}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">Unlocked through gameplay</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>High Scores</CardTitle>
              <CardDescription>Your best performances</CardDescription>
            </CardHeader>
            <CardContent>
              {stats?.highScores?.length > 0 ? (
                <div className="space-y-4">
                  {stats.highScores.map((score, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
                          <Trophy className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{score.name}</p>
                        </div>
                      </div>
                      <div className="font-bold">{score.high_score.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">Play some games to see your high scores!</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Games</CardTitle>
              <CardDescription>Your latest gaming activity</CardDescription>
            </CardHeader>
            <CardContent>
              {stats?.recentGames?.length > 0 ? (
                <div className="space-y-4">
                  {stats.recentGames.map((gameScore) => (
                    <div key={gameScore.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
                          {gameIcons[gameScore.game.name] || <Code className="h-4 w-4 text-primary" />}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{gameScore.game.name}</p>
                          <p className="text-xs text-muted-foreground">{formatTimeAgo(gameScore.playedAt)}</p>
                        </div>
                      </div>
                      <div className="font-bold">{gameScore.score.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No recent games. Start playing!</p>
              )}
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="achievements" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Game Achievements</CardTitle>
            <CardDescription>Badges and rewards earned through gameplay</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
              <AchievementCard
                title="First Game"
                description="Play your first coding game"
                icon={<Award className="h-5 w-5" />}
                unlocked={stats?.gamesPlayed > 0}
              />
              <AchievementCard
                title="Game Master"
                description="Play 5 different types of games"
                icon={<Star className="h-5 w-5" />}
                unlocked={false}
              />
              <AchievementCard
                title="High Scorer"
                description="Score over 1000 points in any game"
                icon={<Trophy className="h-5 w-5" />}
                unlocked={false}
              />
              <AchievementCard
                title="Dedicated Player"
                description="Play 10 coding games"
                icon={<Award className="h-5 w-5" />}
                unlocked={stats?.gamesPlayed >= 10}
              />
              <AchievementCard
                title="Debug Master"
                description="Complete all debug challenges"
                icon={<Bug className="h-5 w-5" />}
                unlocked={false}
              />
              <AchievementCard
                title="Algorithm Genius"
                description="Solve 5 algorithm challenges"
                icon={<Brain className="h-5 w-5" />}
                unlocked={false}
              />
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}

function AchievementCard({ title, description, icon, unlocked }) {
  return (
    <Card className={`border ${unlocked ? "bg-primary/5" : "bg-muted/30 opacity-70"}`}>
      <CardContent className="pt-6">
        <div className="flex flex-col items-center text-center">
          <div
            className={`mb-4 flex h-12 w-12 items-center justify-center rounded-full ${
              unlocked ? "bg-primary/10" : "bg-muted"
            }`}
          >
            <div className={unlocked ? "text-primary" : "text-muted-foreground"}>{icon}</div>
          </div>
          <h3 className="text-lg font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
          <Badge variant={unlocked ? "default" : "outline"} className="mt-4">
            {unlocked ? "Unlocked" : "Locked"}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
