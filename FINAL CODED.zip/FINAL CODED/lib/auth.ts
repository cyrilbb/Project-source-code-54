import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import * as bcrypt from "bcryptjs"

// Session duration (7 days)
const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, 10)
}

export async function comparePasswords(password: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(password, hashedPassword)
}

export async function createSession(userId: number) {
  // Generate a random session token
  const sessionToken = crypto.randomUUID()
  const expires = new Date(Date.now() + SESSION_DURATION)

  // Store the session in the database
  await prisma.session.create({
    data: {
      sessionToken,
      userId,
      expires,
    },
  })

  // Set the session cookie
  cookies().set({
    name: "session_token",
    value: sessionToken,
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    expires,
  })
}

export async function getCurrentUser() {
  const sessionToken = cookies().get("session_token")?.value

  if (!sessionToken) {
    return null
  }

  // Find the session
  const session = await prisma.session.findUnique({
    where: {
      sessionToken,
    },
    include: {
      user: true,
    },
  })

  // Check if session exists and is not expired
  if (!session || session.expires < new Date()) {
    cookies().delete("session_token")
    return null
  }

  return session.user
}

export async function logout() {
  const sessionToken = cookies().get("session_token")?.value

  if (sessionToken) {
    // Delete the session from the database
    await prisma.session.delete({
      where: {
        sessionToken,
      },
    })

    // Delete the session cookie
    cookies().delete("session_token")
  }
}

export async function requireAuth() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/login")
  }

  return user
}

export async function updateLoginStreak(userId: number) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { lastLogin: true, loginStreak: true },
  })

  if (!user) return

  const now = new Date()
  const lastLogin = user.lastLogin

  // Calculate if this login should increase the streak
  let newStreak = user.loginStreak

  if (lastLogin) {
    const lastLoginDate = new Date(lastLogin)
    const daysSinceLastLogin = Math.floor((now.getTime() - lastLoginDate.getTime()) / (1000 * 60 * 60 * 24))

    if (daysSinceLastLogin <= 1) {
      // If logged in today or yesterday, increase streak
      newStreak += 1
    } else {
      // Reset streak if more than a day has passed
      newStreak = 1
    }
  } else {
    // First login
    newStreak = 1
  }

  // Update user's login streak and last login time
  await prisma.user.update({
    where: { id: userId },
    data: {
      loginStreak: newStreak,
      lastLogin: now,
    },
  })
}
